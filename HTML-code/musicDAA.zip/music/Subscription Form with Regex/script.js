document.getElementById('subscriptionForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    
    // Clear previous messages
    document.getElementById('emailError').textContent = '';
    document.getElementById('message').style.display = 'none';
    
    // Email validation using regex
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    
    if (emailRegex.test(email)) {
        // Success
        document.getElementById('message').textContent = 'Successfully subscribed!';
        document.getElementById('message').style.display = 'block';
        document.getElementById('message').style.background = '#d4edda';
        document.getElementById('message').style.color = '#155724';
        document.getElementById('subscriptionForm').reset();
    } else {
        // Failure
        document.getElementById('emailError').textContent = 'Please enter a valid email address';
        document.getElementById('message').textContent = 'Subscription failed. Please check your email.';
        document.getElementById('message').style.display = 'block';
        document.getElementById('message').style.background = '#f8d7da';
        document.getElementById('message').style.color = '#721c24';
    }
});