const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

let students = [];
let nextId = 1;

// Get all students
app.get('/students', (req, res) => {
  res.json(students);
});

// Get student by ID
app.get('/students/:id', (req, res) => {
  const student = students.find(s => s.id === parseInt(req.params.id));
  if (!student) return res.status(404).json({ message: 'Student not found' });
  res.json(student);
});

// Create student
app.post('/students', (req, res) => {
  const student = {
    id: nextId++,
    name: req.body.name,
    age: req.body.age,
    grade: req.body.grade
  };
  students.push(student);
  res.status(201).json(student);
});

// Update student
app.put('/students/:id', (req, res) => {
  const student = students.find(s => s.id === parseInt(req.params.id));
  if (!student) return res.status(404).json({ message: 'Student not found' });
  
  student.name = req.body.name || student.name;
  student.age = req.body.age || student.age;
  student.grade = req.body.grade || student.grade;
  res.json(student);
});

// Delete student
app.delete('/students/:id', (req, res) => {
  const index = students.findIndex(s => s.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ message: 'Student not found' });
  
  students.splice(index, 1);
  res.json({ message: 'Student deleted' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});