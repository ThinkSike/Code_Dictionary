const quizData = [
    {
        question: "What is the capital of France?",
        options: ["London", "Paris", "Berlin", "Madrid"],
        correct: 1
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Venus", "Mars", "Jupiter", "Saturn"],
        correct: 1
    },
    {
        question: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        correct: 1
    },
    {
        question: "Who wrote 'Romeo and Juliet'?",
        options: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"],
        correct: 1
    }
];

let currentQuestion = 0;
let score = 0;
let selectedOption = null;

function loadQuestion() {
    const question = quizData[currentQuestion];
    document.getElementById('question').textContent = `Question ${currentQuestion + 1}: ${question.question}`;
    
    const optionsDiv = document.getElementById('options');
    optionsDiv.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const btn = document.createElement('button');
        btn.textContent = option;
        btn.className = 'option';
        btn.onclick = () => selectOption(index, btn);
        optionsDiv.appendChild(btn);
    });
    
    selectedOption = null;
}

function selectOption(index, btn) {
    const options = document.querySelectorAll('.option');
    options.forEach(opt => opt.classList.remove('selected'));
    btn.classList.add('selected');
    selectedOption = index;
}

document.getElementById('nextBtn').addEventListener('click', function() {
    if (selectedOption === null) {
        alert('Please select an option');
        return;
    }
    
    if (selectedOption === quizData[currentQuestion].correct) {
        score++;
    }
    
    currentQuestion++;
    
    if (currentQuestion < quizData.length) {
        loadQuestion();
    } else {
        showResult();
    }
});

function showResult() {
    document.getElementById('quiz').style.display = 'none';
    document.getElementById('result').style.display = 'block';
    document.getElementById('score').textContent = `Your Score: ${score} out of ${quizData.length}`;
}

document.getElementById('restartBtn').addEventListener('click', function() {
    currentQuestion = 0;
    score = 0;
    document.getElementById('quiz').style.display = 'block';
    document.getElementById('result').style.display = 'none';
    loadQuestion();
});

loadQuestion();