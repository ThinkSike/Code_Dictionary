const API_URL = 'http://localhost:3000/api/students';

document.getElementById('studentForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('studentId').value;
    const student = {
        name: document.getElementById('name').value,
        age: document.getElementById('age').value,
        grade: document.getElementById('grade').value
    };

    if (id) {
        await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(student)
        });
    } else {
        await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(student)
        });
    }

    document.getElementById('studentForm').reset();
    document.getElementById('studentId').value = '';
    loadStudents();
});

async function loadStudents() {
    const response = await fetch(API_URL);
    const students = await response.json();
    
    const studentsList = document.getElementById('studentsList');
    studentsList.innerHTML = students.map(student => `
        <div class="student-item">
            <h3>${student.name}</h3>
            <p>Age: ${student.age}</p>
            <p>Grade: ${student.grade}</p>
            <button class="edit-btn" onclick="editStudent('${student._id}', '${student.name}', ${student.age}, '${student.grade}')">Edit</button>
            <button class="delete-btn" onclick="deleteStudent('${student._id}')">Delete</button>
        </div>
    `).join('');
}

function editStudent(id, name, age, grade) {
    document.getElementById('studentId').value = id;
    document.getElementById('name').value = name;
    document.getElementById('age').value = age;
    document.getElementById('grade').value = grade;
}

async function deleteStudent(id) {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    loadStudents();
}

loadStudents();